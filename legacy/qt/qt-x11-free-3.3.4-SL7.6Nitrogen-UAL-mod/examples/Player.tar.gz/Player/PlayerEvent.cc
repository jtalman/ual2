
#include "UAL/QT/Player/PlayerEvent.hh"

UAL::QT::PlayerEvent::PlayerEvent()
  : QCustomEvent(65432)
{

}
