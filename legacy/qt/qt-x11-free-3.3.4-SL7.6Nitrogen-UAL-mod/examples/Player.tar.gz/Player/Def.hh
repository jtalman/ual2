
#ifndef UAL_QT_DEF_HH
#define UAL_QT_DEF_HH

namespace UAL {

/**
   QT-Based Interactive Analysis Environment of Unified Accelerator Libraries,
   authors: Valeri Fine, Nikolay Malitsky, Richard Talman
 */

  namespace QT {
  }

}

#endif

