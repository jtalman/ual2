#include "UAL/QT/Player/BasicEditor.hh"

UAL::QT::BasicEditor::BasicEditor(QWidget* parent, const char *name)
  : TablePageUI(parent, name)
{
}

UAL::QT::BasicEditor::~BasicEditor()
{
}

void UAL::QT::BasicEditor::activateChanges()
{
}
