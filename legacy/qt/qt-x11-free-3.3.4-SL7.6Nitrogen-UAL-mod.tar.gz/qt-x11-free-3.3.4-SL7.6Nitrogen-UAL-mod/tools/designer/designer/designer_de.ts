<!DOCTYPE TS><TS>
<context encoding="UTF-8">
    <name>AboutDialog</name>
    <message encoding="UTF-8">
        <source>Qt Designer</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Version 2.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Copyright (C) 2000-2001 Trolltech AS</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;p&gt;This program is licensed to you under the terms of the GNU General Public License Version 2 as published by the Free Software Foundation. This gives you legal permission to copy, distribute and/or modify this software under certain conditions. For details, see the file &apos;COPYING&apos; that came with this software distribution. If you did not get the file, send email to info@trolltech.com.&lt;/p&gt;
&lt;p&gt;The program is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionEditor</name>
    <message>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New &amp;Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Action &amp;Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New &amp;Dropdown Action Group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>ActionEditorBase</name>
    <message encoding="UTF-8">
        <source>Edit Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Create new Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete current Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Connect current action</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionListView</name>
    <message>
        <source>New &amp;Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Action &amp;Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New &amp;Dropdown Action Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Connect Action...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Action</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConnectionEditor</name>
    <message>
        <source>Signals (%1):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect/Disconnect signals and slots of &apos;%1&apos; and &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add connections</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>ConnectionEditorBase</name>
    <message encoding="UTF-8">
        <source>Edit Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Edit Connections&lt;/b&gt;&lt;p&gt;Add and remove connections in the current form .&lt;/p&gt;&lt;p&gt;Select a signal and a corresponding slot and press the &lt;b&gt;Connect&lt;/b&gt;-button to create a connection.&lt;/p&gt;&lt;p&gt;Select a connection from the list and press the &lt;b&gt;Disconnect&lt;/b&gt;-button to delete the connection.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Receiver</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Displays the connections between the sender and the receiver.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Si&amp;gnals:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;A list of slots for the receiver.&lt;/b&gt;&lt;p&gt;Only those slots are displayed that have arguments corresponding with the signal selected in the Signal-list.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Connec&amp;tions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Co&amp;nnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Create connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Create the connection between signal and slot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Remove selected connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Remove the selected connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Edit Slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Displays a list of signals for the emitting widget.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Slots:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConnectionViewer</name>
    <message>
        <source>Remove connection between %1 and %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>ConnectionViewerBase</name>
    <message encoding="UTF-8">
        <source>View Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;View Connections&lt;/b&gt;&lt;p&gt;Displays all connections in the current form Select a connection from the list and click the &lt;b&gt;Edit&lt;/b&gt;-button to change the connection.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close the Dialog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Receiver</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Displays a list of connections.&lt;/b&gt;&lt;p&gt;Select a connection and choose edit, or double-click on an item to change the connection.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Edit connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Opens a dialog to change the selected connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>CreateTemplate</name>
    <message encoding="UTF-8">
        <source>Create Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Template &amp;Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Name of the new template</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Enter the name of the new template here</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Class of the new template</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose the class which should be used as baseclass for the new template here</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>C&amp;reate</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Creates the new template</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Closes the Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Baseclass for Template:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomWidgetEditor</name>
    <message>
        <source>Adding a Custom Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There exists already a custom widget with the name &apos;%1&apos;,
so it is not possible to add another one with this name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removing Custom Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The custom widget &apos;%1&apos; is currently used, so it can&apos;t be removed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header Files (*.h *.h++ *.hxx *.hh)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renaming a Custom Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The name &apos;%1&apos; is already use by another custom widget,
so it is not possible to rename it to this name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>protected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom-Widget Description (*.cw);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>CustomWidgetEditorBase</name>
    <message encoding="UTF-8">
        <source>Edit Custom Widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Edit Custom Widgets&lt;/b&gt;&lt;p&gt;Add and remove custom widgets to the designer&apos;s database, and change the properties of existing widgets.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>The list of all custom widgets known to the designer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;New Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add new custom widget.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Create an empty custom widget and add it to the list.&lt;/b&gt;&lt;p&gt;New custom widgets have a default name and header-file, which must both be provided.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Delete Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete custom widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Delete the selected custom widget.&lt;/b&gt;&lt;p&gt;You can only delete widgets that are not used in any open form.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Closes the Dialog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Load Descriptions...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Loads widget description file</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Load Descriptions&lt;/b&gt;&lt;p&gt;Loads a file which contains descriptions of custom widgets, so that these custom widgets can be used in the Qt Designer.&lt;/p&gt;
&lt;p&gt;As it is a lot of work to type in all the information for custom widgets, you should check the tool createcw which you can find in $QTDIR/tools/designer/tools/createcw. Using that tool you can create custom widget description files for your custom widgets without the need of typing in all that information. For more information about that see the README file in that directory&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Save Descriptions...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Saves widget description file</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Save Descriptions&lt;/b&gt;&lt;p&gt;Saves all descriptions of the shown custom widgets to file which can be used to import these custom widgets somewhere else.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change properties for the selected custom widget.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>De&amp;finition</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select a Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Select a pixmap-file.&lt;/b&gt;&lt;p&gt;The pixmap will be used to represent the widget in forms.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Enter filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Change the headerfile&apos;s name for the selected custom widget.&lt;/b&gt;&lt;p&gt;The headerfile will be included by forms using the widget.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose headerfile</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Look for the headerfile in a filedialog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select access</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Change how the include file will be included.&lt;/b&gt;&lt;p&gt;Global include-files will be included using &amp;lt;&amp;gt;-brackets, while local files will included using quotation marks.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change classname</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Enter the classname for the selected customwidget.&lt;/b&gt;&lt;p&gt;A class of that name has to be defined in the headerfile.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Heade&amp;rfile:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Cl&amp;ass:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Pixmap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Si&amp;ze Hint:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Size P&amp;olicy</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Fixed</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Minimum</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Maximum</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Preferred</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>MinimumExpanding</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Expanding</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Horizontal Sizepolicy</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose the horizontal sizepolicy here</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Size hint width</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Set the sizehint for the selected widget.&lt;/b&gt;&lt;p&gt;The sizehint provides the recommended size for the widget. Enter a sizehint of -1/-1 if no size is recommended.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Size hint height</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Vertical Sizepolicy</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose the verical sizepolicy for the widget here</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Con&amp;tainer Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Container Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;p&gt;&lt;b&gt;Container Widget&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;If this customwidget should be able to contain other widgets (children), check this checkbox.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Si&amp;gnals</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>The list of all signals the selected widget can emit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>N&amp;ew Signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add new signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Add a new signal for the current custom widget.&lt;/b&gt;&lt;p&gt;An argument list should be provided in the signal&apos;s name, and the name has to be unique.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Dele&amp;te Signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Delete the signal.&lt;/b&gt;&lt;p&gt;All connections using this signal will be deleted, too.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>S&amp;ignal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change signal name</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Change the name of the selected slot.&lt;/b&gt;&lt;p&gt;An argument list should be provided in the signal&apos;s name, and the name has to be unique.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>S&amp;lots</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Access</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>The list of all slots of the selected custom widget.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Sl&amp;ot:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change slot name</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Access:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>public</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>protected</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change slot access</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Change the access policy of the slot.&lt;/b&gt;&lt;p&gt;You can only connect to public slots of the widget.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>N&amp;ew Slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add new slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Add a new slot to the current custom widget.&lt;/b&gt;&lt;p&gt;An argument list should be provided in the signal&apos;s name, and the name has to be unique.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Dele&amp;te Slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Delete the slot.&lt;/b&gt;&lt;p&gt;All connections using this slot will be deleted, too.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>N&amp;ew Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add new property</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Add a new property to the current customwidget.&lt;/b&gt;&lt;p&gt;The properties have to be implemented in the class using the property system of Qt.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Dele&amp;te Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete property</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Deletes the selected property.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>String</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>CString</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>StringList</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Bool</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Int</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>UInt</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Rect</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>SizePolicy</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select property type</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Select the type of the property.&lt;/b&gt;&lt;p&gt;The propertiy has to be implemented in the class using the property system of Qt.&lt;/p&gt;&lt;p&gt;You can use integer types to support enumeration properties in the property editor.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;The list of properties of the current custom widget.&lt;/b&gt;&lt;p&gt;The properties of the custom widget can be changed in the property editor.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change property name</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Enter a name for the property.&lt;/b&gt;&lt;p&gt;The properties have to be implemented in the class using the property system of Qt.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>P&amp;roperty Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>T&amp;ype:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>DatabaseConnectionBase</name>
    <message encoding="UTF-8">
        <source>Edit Database Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;New Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Delete Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Conn&amp;ection</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Connec&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>DatabaseConnectionEditorBase</name>
    <message encoding="UTF-8">
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Connection Details</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>DatabaseConnectionWidget</name>
    <message encoding="UTF-8">
        <source>Edit Database Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Database Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>D&amp;river</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Hostname:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>P&amp;ort</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditSlots</name>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add/Remove slots of &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Some syntatically wrong slots defined.
Remove these slots?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>EditSlotsBase</name>
    <message encoding="UTF-8">
        <source>Edit Slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Edit Slots&lt;/b&gt;&lt;p&gt;Add, change and remove slots of the current form.&lt;/p&gt;&lt;p&gt;Press the &lt;b&gt;Add Slot&lt;/b&gt;-button to create a new slot, enter a slot name and choose an access mode.&lt;/p&gt;&lt;p&gt;Select an entry from the list and press the &lt;b&gt;Delete Slot&lt;/b&gt;-button to remove a slot. All connections using this slot will be removed, too.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Specifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Access</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>In Use</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;This form&apos;s slots.&lt;/b&gt;&lt;p&gt;Select the slot you want to change or delete.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;New Slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add new slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Add a new slot.&lt;/b&gt;&lt;p&gt;New slots have a default name and public access.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Delete Slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Delete the selected slot.&lt;/b&gt;&lt;p&gt;All connections using this slot are removed, too.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Slot Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Slot:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change slot name</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Change the name of the selected slot.&lt;/b&gt;&lt;p&gt;The name should include the argument list and has to be syntactically correct.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Return type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>S&amp;pecifier:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>non virtual</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>virtual</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>pure virtual</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change slot access</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Change the access policy of the slot&lt;/b&gt;&lt;p&gt;All slots will be created virtual and should be reimplemented in subclasses.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Access:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>public</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>protected</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>private</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EventList</name>
    <message>
        <source>New Signal Handler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Signal Handler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add connection</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>FindDialog</name>
    <message encoding="UTF-8">
        <source>Find Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Find:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Forwar&amp;d</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Whole words only</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Case sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Start at &amp;Beginning</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormDefinitionView</name>
    <message>
        <source>Slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>private</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>protected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>public</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Implementation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit...<byte value="x9"/>Alt+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Class Variables</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormFile</name>
    <message>
        <source>Failed to save file %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 saved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt User-Interface Files (*.ui)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save form &apos;%1&apos; as ....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save changes to the form &apos;%1&apos;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Designer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file %1 has been changed outside Qt Designer.
Do you want to reload it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The project contains already a form with the
filename &apos;%1&apos;. Please choose a new filename.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>FormSettingsBase</name>
    <message encoding="UTF-8">
        <source>Form Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Form Settings&lt;/b&gt;&lt;p&gt;Change settings for the form. Settings like &lt;b&gt;Comment&lt;/b&gt; and &lt;b&gt;Author&lt;/b&gt; are for personal use and not required.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Pixmaps</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Save In&amp;line</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Save pixmaps into the .ui files</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Save Inline&lt;/b&gt;&lt;p&gt;Saves the pixmaps you choose as binary data into the .ui files. Pixmaps are not shared between forms. We recommend using Project Imagefiles instead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Project &amp;Imagefile</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Use the Project&apos;s Image file to load pixmaps</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Use the Project&apos;s Image file to open pixmaps&lt;/b&gt;
&lt;p&gt;Each project has a collection of pixmaps. If you use a project, we recommend that you use this option since it shares images and is the fastest and most efficient way to use pixmaps in your forms.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Specify Pixmap-Loader function (only function-name, no parentheses!)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Specify Pixmap-Loader function&lt;/b&gt;&lt;p&gt;Specify the function which should be used for loading a pixmap in the generated code. &lt;em&gt;Only enter the function-name, no parentheses!&lt;/em&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Use &amp;Function:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Use a defined function to load pixmaps</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Use a defined function to open pixmaps&lt;/b&gt;&lt;p&gt;If you choose this option you must define a function in the line edit at the right which will be used in the generated code for loading pixmaps. When choosing a pixmap in &lt;i&gt;Qt Designer&lt;/i&gt; you will be asked to specify the arguments which will be passed to the function in the generated code.&lt;p&gt; This approach makes it possible to use your own icon-loader function for loading pixmaps.  &lt;i&gt;Qt Designer&lt;/i&gt; can&apos;t preview the correct image if you use your own function.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change class name</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Enter the name of the class that will be created.&lt;/b&gt;&lt;p&gt;&lt;em&gt;classname.h&lt;/em&gt; and &lt;em&gt;classname.cpp&lt;/em&gt; will be generated as C++-output when it is compiled with the uic.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>A&amp;uthor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Enter your name</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Enter your name here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Class &amp;Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Co&amp;mment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Enter a comment about the form.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>La&amp;youts</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Default Mar&amp;gin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>D&amp;efault Spacing:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormWindow</name>
    <message>
        <source>Set &apos;name&apos; property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The name of a widget has to be unique!
&apos;%1&apos; is already used in the form &apos;%2&apos;,
so the name has been changed back to &apos;%3&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The name of a widget must not be null!
The name has been changed back to &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;A %1 (custom widget)&lt;/b&gt; &lt;p&gt;Select &lt;b&gt;Edit Custom Widgets...&lt;/b&gt; in the &lt;b&gt;Tools-&gt;Custom&lt;/b&gt; menu to add and change the custom widgets. You can add properties as well as signals and slots to integrate them into the designer, and provide a pixmap which will be used to represent the widget on the form.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A %1 (custom widget)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reparent Widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect &apos;%1&apos; with...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1/%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect &apos;%1&apos; with &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inserting a Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You tried to insert a widget into the laid out Container Widget &apos;%1&apos;.
This is not possible. In order to insert the widget, the layout of &apos;%1&apos;
has to be broken. Break the layout or cancel the operation?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Break Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Size Hint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjust Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click widgets to change tab order...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drag a line to create a connection...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click on the form to insert a %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Following custom widgets are used in &apos;%1&apos;,
but they are not known to the designer:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Accelerators</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The accelerator &apos;%1&apos; is used %2 times.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No accelerator is used more than once!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Raise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout horizontally (in splitter)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout vertically (in splitter)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout in a grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout children horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout children vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout children in a grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Break Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit connections...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>GotoLineDialog</name>
    <message encoding="UTF-8">
        <source>Goto Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Line:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Goto</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HierarchyList</name>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Page to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Page %1 of %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HierarchyView</name>
    <message>
        <source>Widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Classes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IconViewEditor</name>
    <message>
        <source>New Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Items of &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>IconViewEditorBase</name>
    <message encoding="UTF-8">
        <source>Edit Iconview</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Edit Iconview&lt;/b&gt;&lt;p&gt;Add, change and remove items in the icon view.&lt;/p&gt;&lt;p&gt;Press the &lt;b&gt;New Item&lt;/b&gt;-button to create a new entry, and enter a text or choose a pixmap.&lt;/p&gt;&lt;p&gt;Select an item from the view and press the &lt;b&gt;Delete Item&lt;/b&gt;-button to remove the item from the view.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>All items in the view.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;New Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add an item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Create a new item for the view.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Delete Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete the selected item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Item Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change text</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change the text for the selected item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Pixmap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Label4</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete the pixmap of the selected item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select a Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select a pixmap-file for the current item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListBoxEditor</name>
    <message>
        <source>New Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Items of &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>ListBoxEditorBase</name>
    <message encoding="UTF-8">
        <source>Edit Listbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Edit Listbox&lt;/b&gt;&lt;p&gt;Add, change and remove items in the listbox.&lt;/p&gt;&lt;p&gt;Press the &lt;b&gt;New Item&lt;/b&gt;-button to create a new listbox entry, and enter text or choose a pixmap.&lt;/p&gt;&lt;p&gt;Select an item from the list and press the &lt;b&gt;Delete Item&lt;/b&gt;-button to remove the item from the list.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>The list of items.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Item Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Pixmap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Label4</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete the pixmap of the selected item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select a Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose a pixmap-file for the selected item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change text</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change the text of the selected item.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;New Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add an item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Add a new item.&lt;/b&gt;&lt;p&gt;New items are appended to the list.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Delete Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete the selected item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Move up</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Moves the selected item up.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Move down</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Move the selected item down.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>ListEditor</name>
    <message encoding="UTF-8">
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Column 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Re&amp;name</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ListViewEditor</name>
    <message>
        <source>Edit Items and Columns of &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Items</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>ListViewEditorBase</name>
    <message encoding="UTF-8">
        <source>Edit Listview</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Edit Listview&lt;/b&gt;&lt;p&gt;Use the controls on the &lt;b&gt;Items&lt;/b&gt;-tab to add, change and remove items in the listview. Change the column configuration of the view using the controls on the &lt;b&gt;Columns&lt;/b&gt;-tab.&lt;/p&gt;Press the &lt;b&gt;New Item&lt;/b&gt;-button to create a new item and enter a text or provide a pixmap.&lt;/p&gt;&lt;p&gt;Select an item from the list and press the &lt;b&gt;Delete Item&lt;/b&gt;-button to remove the item from the list.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Delete Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Deletes the selected item.&lt;/b&gt;&lt;p&gt;Existing subitems are deleted, too.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Item &amp;Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Pi&amp;xmap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change text</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Change the text of the item.&lt;/b&gt;&lt;p&gt;The text will be changed in the current column of the selected item.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Change column</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Select the current column.&lt;/b&gt;&lt;p&gt;Itemtext and pixmap will be changed for the current column&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Colu&amp;mn:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Label4</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Delete the pixmap of the selected item.&lt;/b&gt;&lt;p&gt;The pixmap in the current column of the selected item will be deleted.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select a Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Select a pixmap-file for the item.&lt;/b&gt;&lt;p&gt;The pixmap will be changed in the current column of the selected item.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;New Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add an item</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Adds a new item to the list.&lt;/b&gt;&lt;p&gt;The item will be inserted at the top of the list and can be moved using the up- and down-buttons.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>The list of items.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>New &amp;Subitem</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add a subitem</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Create a new subitem for the selected item.&lt;/b&gt;&lt;p&gt;New subitems are inserted at the top of the list of subitems, and new levels will be created automatically.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Move up</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Move the selected item up.&lt;/b&gt;&lt;p&gt;The item will be moved within the hierarchy level.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Move down</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Move the selected item down.&lt;/b&gt;&lt;p&gt;The item will be moved within the hierarchy level.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Move left</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Move the selected item one level up.&lt;/b&gt;&lt;p&gt;This will also change the level of the parent item.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Move right</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Move the selected item one level down.&lt;/b&gt;&lt;p&gt;This will also change the level of the parent item.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Co&amp;lumns</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Column Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Pixmap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete the pixmap of the selected column.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Select a pixmap-file for the selected column.&lt;/b&gt;&lt;p&gt;The pixmap will be displayed in the header of the listview.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Enter column text</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Enter the text for the selected column.&lt;/b&gt;&lt;p&gt;The text will be displayed in the header of the listview.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Clicka&amp;ble</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>If this option is checked, the selected column will react on mouseclicks on the header.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Re&amp;sizable</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>The column&apos;s width will be resizeable if this option is checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Delete Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete column</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Deletes the selected Column.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Move the selected item down.&lt;/b&gt;&lt;p&gt;The topmost column will be the first column of the list.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;New Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add a Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Create a new column.&lt;/b&gt;&lt;p&gt;New columns are appended to the list and may be moved using the up- and down-buttons.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Move the selected item up.&lt;/b&gt;&lt;p&gt;The topmost column will be the first column of the list.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>The list of columns.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Qt User-Interface Files (*.ui)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ready - This is the non-commercial version of Qt - For commercial evaluation purposes, use the help menu to register with Trolltech.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Property Editor/Signal Handlers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The Property Editor&lt;/b&gt;&lt;p&gt;You can change the appearance and behaviour of the selected widget in the property editor.&lt;/p&gt;&lt;p&gt;You can set properties for components and forms at design time and see the changes immediately. Each property has its own editor which you can use to enter new values, open a special dialog or select values from a predefined list. Use &lt;b&gt;F1&lt;/b&gt; to get detailed help for the selected property.&lt;/p&gt;&lt;p&gt;You can resize the columns of the editor by dragging the separators of the list header.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Signal Handlers&lt;/b&gt;&lt;/p&gt;&lt;p&gt;In the Signal Handlers tab you can define connections between signals of widgets and slots of the form. That is just a convenience way, you can use the connection tool to do that as well.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object Explorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The Object Explorer&lt;/b&gt;&lt;p&gt;The object explorer gives a quick overview about the relations between the widgets in your form. You can use the clipboard functions using a context menu for each item in the view.&lt;/p&gt;&lt;p&gt;The columns can be resized by dragging the separator in the list header.&lt;/p&gt;&lt;p&gt;On the second tab you can see all the declared slots, variables, includes, etc. of the form.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start typing the buffer you want to switch to here (ALT+B)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Overview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The File Overview box&lt;/b&gt;&lt;p&gt;The File Overview Box displays all files of all projects, including forms and source files.&lt;/p&gt;&lt;p&gt;Its search field allows rapid switching between files.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The Action Editor&lt;/b&gt;&lt;p&gt;Todo Whatsthis&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Couldn&apos;t find the Qt documentation property index file!
Define the correct documentation path in the preferences dialog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The Form Window&lt;/b&gt;&lt;p&gt;Use the different tools to add widgets or to change the layout and behaviour of the components in your form. Select one or multiple widgets and move them, or resize a single widget using the handles.&lt;/p&gt;&lt;p&gt;Changes in the &lt;b&gt;Property Editor&lt;/b&gt; can be seen at design time, and you can open a preview of your form in different styles.&lt;/p&gt;&lt;p&gt;You can change the grid resolution, or turn the grid off in the &lt;b&gt;Preferences&lt;/b&gt; dialog in the &lt;b&gt;Edit&lt;/b&gt; menu.&lt;p&gt;You can have several forms open, and all open forms are listed in the &lt;b&gt;Form List&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot create invalid project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Undo: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Undo: Not Available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Redo: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Redo: Not Available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Pixmap...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Text...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Title...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Page Title...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Menu Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set &apos;text&apos; of &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set &apos;title&apos; of &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New page title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set &apos;pageTitle&apos; of &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set &apos;pixmap&apos; of &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Page to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Page %1 of %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename page %1 of %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Toolbar to &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Menu to &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Project Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save changes to &apos;%1&apos;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restoring last session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Qt Designer found some temporary saved files, which have been
written when the Qt Designer crashed last time. Do you want to
load these files?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There is no help available for this dialog at the moment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open &apos;%1&apos;. File does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverses the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redoes the last undone operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cuts the selected widgets and puts them on the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copies the selected widgets to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pastes clipboard contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deletes the selected widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selects all widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bring to Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bring to &amp;Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Raises the selected widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send to Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send to &amp;Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lowers the selected widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Accelerators</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chec&amp;k Accelerators</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checks if the accelerators used in the form are unique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;lots...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens a dialog to edit slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Co&amp;nnections...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens a dialog to edit connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Source...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens an editor to edit the source of the form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Form Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens a dialog to change the settings of the form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens a dialog to change preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The Edit toolbar&lt;/b&gt;%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Find...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find Incremental</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find &amp;Incremental</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Replace...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Goto Line...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incremetal Search (ALT+I)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjust Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjust &amp;Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjusts the size of the selected widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lay Out Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lay Out &amp;Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lays out the selected widgets horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lay Out Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lay Out &amp;Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lays out the selected widgets vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lay Out in a Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lay Out in a &amp;Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lays out the selected widgets in a grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lay Out Horizontally (in Splitter)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lay Out Horizontally (in S&amp;plitter)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lays out the selected widgets horizontally in a splitter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lay Out Vertically (in Splitter)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lay Out Vertically (in Sp&amp;litter)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lays out the selected widgets vertically in a splitter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Break Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Break Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Breaks the selected layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert a %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The Layout toolbar&lt;/b&gt;%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selects the pointer tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect Signal/Slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Connect Signal/Slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selects the connection tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab &amp;Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selects the tab order tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The Tools toolbar&lt;/b&gt;%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit &amp;Custom Widgets...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens a dialog to change the custom widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The %1&lt;/b&gt;%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Click on a button to insert a single widget, or double click to insert multiple %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The %1 Widgets&lt;/b&gt;%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Click on a button to insert a single %1 widget, or double click to insert multiple widgets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Double click on this tool to keep it selected.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The Custom Widgets toolbar&lt;/b&gt;%1&lt;p&gt;Select &lt;b&gt;Edit Custom Widgets...&lt;/b&gt; in the &lt;b&gt;Tools-&gt;Custom&lt;/b&gt; menu to add and change custom widgets&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Click on the buttons to insert a single widget, or double click to insert multiple widgets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The File toolbar&lt;/b&gt;%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creates a new project, form or source file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens an existing project, form for source file </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Closes the current project or document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saves the current project or document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saves the current form with a new filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sa&amp;ve All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saves all open documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create &amp;Template...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Creates a new template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recently opened files </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recently opened projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quits the application and prompts to save changed forms, source files and project settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pr&amp;oject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;No Project&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Add File...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adds a file to the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Collection...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Image Collection...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens a dialog to edit the image collection of the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Connections...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Database Connections...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens a dialog to edit the database connections of the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Project Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens a dialog to change the settings of the project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview &amp;Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens a preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The preview will use the Motif Look&amp;Feel used as the default style on most UNIX-Systems.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The preview will use the Windows Look&amp;Feel used as the default style on Windows-Systems.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The preview will use the Platinum Look&amp;Feel resembling a Macinosh-like GUI style.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The preview will use the CDE Look&amp;Feel which is similar to some versions of the Common Desktop Environment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The preview will use the Motif Look&amp;Feel used as the default style on SGI-systems.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The preview will use an advanced Motif Look&amp;Feel as used by the GIMP toolkit (GTK) on Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview Form in %1 Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>... in %1 Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens a preview in %1 style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Open a preview in %1 style.&lt;/b&gt;&lt;p&gt;Use the preview to test the design and signal-slot connections of the current form. %2&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Tile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arranges all windows tiled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cascade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cascade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arrange all windows cascaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cl&amp;ose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Closes the active window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close Al&amp;l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Closes all form windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ne&amp;xt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activates the next window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pre&amp;vious</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activates the previous window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tool&amp;bars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens the online help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens the Qt Designer manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Displays information about this product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Displays information about the Qt Toolkit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Register Qt...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Launches web browser with evaluation form at www.trolltech.com</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register with Trolltech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What&apos;s This?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&quot;What&apos;s This?&quot; context sensitive help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;The Help toolbar&lt;/b&gt;%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select new item ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Designer Files (*.ui *.pro)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QMAKE Project Files (*.pro)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No import filter available for %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importing %1 using import filter ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing to load in %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reading file %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File %1 opened.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to load file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Couldn&apos;t load file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project &apos;%1&apos; saved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a filename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Designer is crashing - attempting to save work...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NewTemplate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Couldn&apos;t create the template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit slots of current form...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit connections in current form...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit settings of current form...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit custom widgets...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Column 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Template</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MultiLineEditor</name>
    <message>
        <source>Set text of &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>MultiLineEditorBase</name>
    <message encoding="UTF-8">
        <source>Edit Multiline Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Edit Multiline Edit&lt;/b&gt;&lt;p&gt;Enter the text and press the &lt;b&gt;OK&lt;/b&gt;-Button to apply the changes.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Enter your text here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewForm</name>
    <message>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wizard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main Window</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>NewFormBase</name>
    <message encoding="UTF-8">
        <source>New File</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;New Form&lt;/b&gt;&lt;p&gt;Select a template for the new form and click the &lt;b&gt;OK&lt;/b&gt;-button to open it.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Open a new form using the selected template.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and do not open a form.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Displays a list of available templates.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Insert into:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OutputWindow</name>
    <message>
        <source>Error Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>PaletteEditorAdvancedBase</name>
    <message encoding="UTF-8">
        <source>Tune Palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Edit Palette&lt;/b&gt;&lt;p&gt;Change the palette of the current widget or form.&lt;/p&gt;&lt;p&gt;Use a generated palette or select colors for each color group and each color role.&lt;/p&gt;&lt;p&gt;The palette can be tested with different widget layouts in the preview section.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select &amp;Palette:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Active Palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Inactive Palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Disabled Palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Build inactive palette from active.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Build disabled palette from active.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Central color &amp;roles</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Foreground</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Base</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>BrightText</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>ButtonText</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>HighlightText</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>LinkVisited</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose central color role</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Select a color role.&lt;/b&gt;&lt;p&gt;Available central roles are: &lt;ul&gt; &lt;li&gt;Background - general background color.&lt;/li&gt; &lt;li&gt;Foreground - general foreground color. &lt;/li&gt; &lt;li&gt;Base - used as background color for e.g. text entry widgets, usually white or another light color. &lt;/li&gt; &lt;li&gt;Text - the forground color used with Base. Usually this is the same as the Foreground, in what case it must provide good contrast both with Background and Base. &lt;/li&gt; &lt;li&gt;Button - general button background color, where buttons need a background different from Background, as in the Macintosh style. &lt;/li&gt; &lt;li&gt;ButtonText - a foreground color used with the Button color. &lt;/li&gt; &lt;li&gt;Highlight - a color to indicate a selected or highlighted item. &lt;/li&gt; &lt;li&gt;HighlightedText - a text color that contrasts to Highlight. &lt;/li&gt; &lt;li&gt;BrightText - a text color that is very different from Foreground and contrasts well with e.g. black. &lt;/li&gt; &lt;/ul&gt; &lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose Pi&amp;xmap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select a pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose a pixmap-file for the selected central color role.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Select Color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose a color</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose a color for the selected central color role.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>3-D shadow &amp;effects</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Build &amp;from button color</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Generate shadings</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Check to let 3D-effect colors be calculated from button-color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Midlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Mid</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Shadow</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose 3D-effect color role</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Select a color role.&lt;/b&gt;&lt;p&gt;Available effect roles are: &lt;ul&gt; &lt;li&gt;Light - lighter than Button color. &lt;/li&gt; &lt;li&gt;Midlight - between Button and Light. &lt;/li&gt; &lt;li&gt;Mid - between Button and Dark. &lt;/li&gt; &lt;li&gt;Dark - darker than Button. &lt;/li&gt; &lt;li&gt;Shadow - a very dark color. &lt;/li&gt; &lt;/ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select Co&amp;lor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose a color for the selected effect color role.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>PaletteEditorBase</name>
    <message encoding="UTF-8">
        <source>Edit Palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Build Palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;3-D Effects:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose a color</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose the effect-color for the generated palette.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Back&amp;ground:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose the background color for the generated palette.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Tune Palette...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select &amp;Palette:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Active Palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Inactive Palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Disabled Palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>PixmapCollectionEditor</name>
    <message encoding="UTF-8">
        <source>Manage Image Collection</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Add...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose an Image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>PixmapFunction</name>
    <message encoding="UTF-8">
        <source>Choose Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Enter arguments for loading the pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>QPixmap(</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>Preferences</name>
    <message encoding="UTF-8">
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Preferences&lt;/b&gt;&lt;p&gt;Change the preferences of the designer application. There is always one tab with general preferenced. Depending on installed plugins, there might be more tabs for plugin preferences.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Backgro&amp;und</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose a color</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select a color in the colordialog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Co&amp;lor</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Use a background color</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Use a background color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Use a background pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Use a background pixmap.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select a pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Choose a pixmap-file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Show &amp;Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Show Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Customize the grid appearance for all forms.&lt;/b&gt;&lt;p&gt;When &lt;b&gt;Show Grid&lt;/b&gt; is checked, all forms show a grid.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Gr&amp;id</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Sn&amp;ap to Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Snap to the grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Customize the grid-settings for all forms.&lt;/b&gt;&lt;p&gt;When &lt;b&gt;Snap to Grid&lt;/b&gt; is checked, the widgets snap to the grid using the the X/Y resolution.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Grid resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Customize the grid-settings for all forms.&lt;/b&gt;&lt;p&gt;When &lt;b&gt;Show Grid&lt;/b&gt; is checked, a grid is shown on all forms using the X/Y resolution.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Grid-&amp;X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Grid-&amp;Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>A splashscreen is displayed when starting the designer if this option is checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Ge&amp;neral</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Restore Last &amp;Workspace on Startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Restore last workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>The current workspace settings will be restored next time you start the designer if this option is checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Show &amp;Splash Screen on Startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Show Splashscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Disable Data&amp;base Auto-Edit in Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Documentation Path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Enter the path to the documentation.&lt;/b&gt;&lt;p&gt;You may provide an $environment variable as first part of your pathname.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select path</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Look for the documentation path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Show &amp;Big Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Big Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Uses big icons in the toolbars when checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Show Text Lab&amp;els</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Text Labels</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Shows textlabels in the toolbars when checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>PreviewWidgetBase</name>
    <message encoding="UTF-8">
        <source>Preview Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>ButtonGroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>RadioButton1</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>RadioButton2</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>RadioButton3</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>ButtonGroup2</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>CheckBox1</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>CheckBox2</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>LineEdit</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>ComboBox</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>PushButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;p&gt;
&lt;a href=&quot;http://www.trolltech.com&quot;&gt; http://www.trolltech.com &lt;/a&gt;
&lt;/p&gt;
&lt;p&gt;
&lt;a href=&quot;http://www.kde.org&quot;&gt; http://www.kde.org &lt;/a&gt;
&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Project</name>
    <message>
        <source>&lt;No Project&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectSettings</name>
    <message>
        <source>unnamed.pro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Files (*.db);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Files (*.pro);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>ProjectSettingsBase</name>
    <message encoding="UTF-8">
        <source>Project Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Project File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>For&amp;ms and Sources:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Add...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Database File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyBoolItem</name>
    <message>
        <source>False</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>True</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyColorItem</name>
    <message>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyCoordItem</name>
    <message>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>height</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyCursorItem</name>
    <message>
        <source>Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up-Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iBeam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size Slash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size Backslash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Split Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Split Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pointing Hand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forbidden</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyDatabaseItem</name>
    <message>
        <source>Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Field</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyEditor</name>
    <message>
        <source>Reset property to its default value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click this button to reset the property to its default value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Property Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Signal Handlers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Property Editor (%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyFontItem</name>
    <message>
        <source>Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Point Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Strikeout</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyList</name>
    <message>
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set &apos;%1&apos; of &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort &amp;Categorized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort &amp;Alphabetically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset &apos;%1&apos; of &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;QWidget::%1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;There is no documentation available for this property.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertySizePolicyItem</name>
    <message>
        <source>hSizeType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>vSizeType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>horizontalStretch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>verticalStretch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1/%2/%2/%2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyTextItem</name>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not connect to the database.
Press &apos;OK&apos; to continue or &apos;Cancel&apos; to specify different
connection information.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDesignerMenuBar</name>
    <message>
        <source>Delete Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Item...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Menu &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Menuitem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Menu Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Menu &apos;%1&apos; to &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move menu &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDesignerPopupMenu</name>
    <message>
        <source>Delete Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Separator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Action &apos;%1&apos; from the Popup Menu &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Separator to the Popup Menu &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Action &apos;%1&apos;  to the Popup Menu &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert/Move Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Action &apos;%1&apos; has already been added to this menu.
An Action can only be added once to the same menu.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDesignerTabWidget</name>
    <message>
        <source>Move Tab Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDesignerToolBar</name>
    <message>
        <source>Delete Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Toolbar &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Separator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Action &apos;%1&apos; from Toolbar &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Separator to Toolbar &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Action &apos;%1&apos; to Toolbar &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert/Move Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Action &apos;%1&apos; has already been added to this toolbar.
An Action can only be added once to the same toolbar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Widget &apos;%1&apos; to Toolbar &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>ReplaceDialog</name>
    <message encoding="UTF-8">
        <source>Replace Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>R&amp;eplace</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Replace &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Whole words only</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Case sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Start at Beginning</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Forwar&amp;d</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Backward</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SizeHandle</name>
    <message>
        <source>%1/%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resize</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SourceEditor</name>
    <message>
        <source>Edit %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SourceFile</name>
    <message>
        <source>Edit %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save changes to &apos;%1&apos;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qt Designer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file %1 has been changed outside Qt Designer.
Do you want to reload it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The project contains already a sourcefile with the
filename &apos;%1&apos;. Please choose a new filename.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TableEditor</name>
    <message>
        <source>Edit Rows and Columns of &apos;%1&apos; </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>TableEditorBase</name>
    <message encoding="UTF-8">
        <source>Edit Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Co&amp;lumns</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Move up</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Move the selected item up.&lt;/b&gt;&lt;p&gt;The topmost column will be the first column of the list.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Move down</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Move the selected item down.&lt;/b&gt;&lt;p&gt;The topmost column will be the first column of the list.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Delete Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;New Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Table:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Label4</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Delete Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Delete the pixmap of the selected item.&lt;/b&gt;&lt;p&gt;The pixmap in the current column of the selected item will be deleted.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Select a Pixmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;b&gt;Select a pixmap-file for the item.&lt;/b&gt;&lt;p&gt;The pixmap will be changed in the current column of the selected item.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Pixmap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Field:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&lt;no table&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Rows</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;New Row</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Delete Row</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextEditor</name>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WizardEditor</name>
    <message>
        <source>Edit Wizard Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Page to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Page %1 of %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swap pages %1 and %2 of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New page title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename page %1 of %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>WizardEditorBase</name>
    <message encoding="UTF-8">
        <source>Wizard Page Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Wizard Pages:</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and apply all changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>Close dialog and discard all changes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Workspace</name>
    <message>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open source file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Remove source file from project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open form...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Remove form from project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open form source...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>qChoosePixmap</name>
    <message>
        <source>All Pixmaps (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1-Pixmaps (%2)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Images...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a Pixmap...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
