void EditBookForm::init()
{
	 
}

void EditBookForm::destroy()
{
    
}

