
#ifdef __MAKECINT__

#pragma link MACRO function char_traits<char>::assign(char_type*,size_t,const char_type);

#endif
