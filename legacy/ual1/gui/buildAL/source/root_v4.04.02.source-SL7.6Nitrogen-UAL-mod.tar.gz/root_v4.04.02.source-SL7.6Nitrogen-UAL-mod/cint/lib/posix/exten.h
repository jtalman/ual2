/***********************************************************************
* exten.h
*  Extention for UNIX/WIN32 common API interface.
*  This source applies to UNIX.
***********************************************************************/
#ifndef G__EXTEN_H
#define G__EXTEN_H

#include "posix.h"
int isDirectory(struct dirent* pd);

#endif
