//double eD=cba.getEnergy();
double mD=cba.getMass();
double qD=cba.getCharge();
double gD=cba.get_g();

/*
double tD=cba.getElapsedTime();
double fD=cba.getRevfreq();
double MD=cba.getMacrosize();
double GD=cba.getG();
double ElD=cba.getE();
*/

double e0=cba.getEnergy();
double m0=cba.getMass();
double q0=cba.getCharge();
double t0=cba.getElapsedTime();
double f0=cba.getRevfreq();
double M0=cba.getMacrosize();
double G0=cba.getG();
double El0=cba.getE();
