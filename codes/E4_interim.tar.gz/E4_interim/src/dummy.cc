#include"PAC/Beam/Position.hh"

#include"ETEAPOT2/Integrator/genMethods/Vectors.h"
#include"ETEAPOT2/Integrator/genMethods/spinExtern"
#include"ETEAPOT2/Integrator/genMethods/spinDef"
#include"ETEAPOT2/Integrator/genMethods/designExtern"
#include"ETEAPOT2/Integrator/genMethods/designDef"
#include"ETEAPOT2/Integrator/genMethods/bunchParticleExtern"
#include"ETEAPOT2/Integrator/genMethods/bunchParticleDef"
int main()
{
  return 1;
}
